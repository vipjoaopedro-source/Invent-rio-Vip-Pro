# Selecionar a pasta do cadastro no Android

## Objetivo
Permitir que o usuário escolha pelo navegador de arquivos do Android a pasta onde está o cadastro, eliminando a dependência de um caminho fixo.

## Alterações
- Substituir a busca automática na raiz pelo botão “Selecionar pasta do cadastro”.
- Abrir o navegador de pastas do próprio Android e permitir apontar a pasta desejada.
- Salvar permanentemente a autorização e a pasta selecionada, inclusive após fechar o aplicativo.
- Procurar dentro dela por `Cadastro`, `Cadastro.txt` ou outro arquivo cujo nome comece com `cadastro`.
- Adicionar “Atualizar cadastro” para reler o arquivo da pasta salva sem pedir a pasta novamente.
- Mostrar o nome da pasta escolhida e mensagens específicas para arquivo ausente, vazio ou ilegível.
- Remover a solicitação de acesso total aos arquivos, pois o seletor concede acesso apenas à pasta escolhida.
- Recompilar e entregar um novo APK.

## Fluxo esperado
1. Em Configurações > Cadastro, o usuário toca em “Selecionar pasta do cadastro”.
2. No navegador do Android, abre `Inventario Vip Pro` e confirma em “Usar esta pasta”.
3. O aplicativo importa o cadastro e memoriza essa pasta.
4. Quando o TXT for substituído, “Atualizar cadastro” relê o arquivo salvo.
