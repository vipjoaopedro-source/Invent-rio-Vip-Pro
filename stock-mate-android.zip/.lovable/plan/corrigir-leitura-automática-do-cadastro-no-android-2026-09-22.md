# Corrigir leitura automática do cadastro no Android

## Objetivo
Ler diretamente o arquivo `Cadastro` ou `Cadastro.txt` dentro da pasta `Inventario Vip Pro` na memória principal do celular, sem travamento e sem depender da leitura limitada atual.

## Alterações
- Criar uma leitura Android própria para acessar a memória principal e localizar pasta e arquivo ignorando maiúsculas, acentos e espaços extras.
- Solicitar corretamente a autorização especial de acesso a arquivos exigida nas versões recentes do Android.
- Aceitar o cadastro com codificação UTF-8 ou ANSI, comum em arquivos TXT exportados por sistemas antigos.
- Retornar mensagens específicas para: autorização pendente, pasta ausente, arquivo ausente, arquivo vazio ou erro de leitura.
- Manter a seleção manual de arquivo como alternativa.
- Recompilar o APK atualizado para instalação e teste no aparelho.

## Fluxo esperado
1. O aplicativo procura `Inventario Vip Pro/Cadastro` ou `Inventario Vip Pro/Cadastro.txt`.
2. Se o Android bloquear o acesso, abre a tela de autorização do próprio aparelho.
3. Após autorizar, o usuário volta ao aplicativo e toca novamente em “Buscar cadastro na pasta”.
4. O cadastro é importado e a quantidade de produtos aparece na tela.
